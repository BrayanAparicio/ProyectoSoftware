// database.js
const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./parqueadero.db');

db.serialize(() => {
    // Crear tabla de vehículos
    db.run("CREATE TABLE IF NOT EXISTS vehiculos (id INTEGER PRIMARY KEY AUTOINCREMENT, placa TEXT, modelo TEXT, fecha_ingreso TEXT, fecha_salida TEXT, estado TEXT)");

    // Crear tabla de usuarios
    db.run("CREATE TABLE IF NOT EXISTS usuarios (id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT, email TEXT UNIQUE, password TEXT, tipo TEXT DEFAULT 'cliente')");

    // Crear tabla de reservas
    db.run("CREATE TABLE IF NOT EXISTS reservas (id INTEGER PRIMARY KEY AUTOINCREMENT, id_usuario INTEGER, placa TEXT, fecha_reserva TEXT, estado TEXT DEFAULT 'pendiente', FOREIGN KEY (id_usuario) REFERENCES usuarios(id))");

    // Crear tabla de facturas
    db.run("CREATE TABLE IF NOT EXISTS facturas (id INTEGER PRIMARY KEY AUTOINCREMENT, id_reserva INTEGER, total DECIMAL(10, 2), fecha_emision TEXT, FOREIGN KEY (id_reserva) REFERENCES reservas(id))");
});

module.exports = db;