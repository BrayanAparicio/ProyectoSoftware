const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const flash = require('connect-flash');
const db = require('./database');
const moment = require('moment-timezone');
const PDFDocument = require('pdfkit');
const fs = require('fs');
const nodemailer = require('nodemailer');

const app = express();

app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({ secret: 'mi_secreto', resave: false, saveUninitialized: true }));
app.use(flash());
app.use(passport.initialize());
app.use(passport.session());

passport.use(new LocalStrategy((username, password, done) => {
  db.get("SELECT * FROM usuarios WHERE email = ?", [username], (err, user) => {
    if (err) return done(err);
    if (!user || password !== user.password) {
      return done(null, false, { message: 'Credenciales incorrectas' });
    }
    return done(null, user);
  });
}));

passport.serializeUser ((user, done) => {
  done(null, user.id);
});

passport.deserializeUser ((id, done) => {
  db.get("SELECT * FROM usuarios WHERE id = ?", [id], (err, user) => {
    done(err, user);
  });
});

// Rutas para usuarios
app.get('/registro', (req, res) => {
  res.render('registro');
});

app.post('/registro', (req, res) => {
  const { nombre, email, password, tipo } = req.body; // Incluye 'tipo'
  db.run("INSERT INTO usuarios (nombre, email, password, tipo) VALUES (?, ?, ?, ?)", [nombre, email, password, tipo], (err) => {
    if (err) {
      return console.log(err.message);
    }
    res.redirect('/login');
  });
});

app.get('/login', (req, res) => {
  res.render('login', { message: req.flash('error') });
});

app.post('/login', (req, res, next) => {
  passport.authenticate('local', (err, user, info) => {
    if (err) { return next(err); } // Manejar errores
    if (!user) {
      req.flash('error', info.message); // Si no hay usuario, mostrar mensaje de error
      return res.redirect('/login'); // Redirigir a login
    }
    
    req.logIn(user, (err) => {
      if (err) { return next(err); }

      // Aquí es donde agregarás los console.log
      console.log('Usuario autenticado:', user); // Verificar el usuario autenticado

      // Redirigir según el tipo de usuario
      // Redirigir según el tipo de usuario
      if (user.tipo === 'admin') { // Cambiar 'Administrador' a 'admin'
        console.log('Redirigiendo a la vista de administrador'); // Mensaje de depuración
        return res.redirect('/admin'); // Redirigir a la vista de admin
      } else {
        console.log('Redirigiendo a la vista de usuario'); // Mensaje de depuración
        return res.redirect('/'); // Redirigir a la vista de usuario
      }
    });
  })(req, res, next);
});

app.post('/login', (req, res, next) => {
  passport.authenticate('local', (err, user, info) => {
    if (err) { return next(err); } // Manejar errores
    if (!user) {
      req.flash('error', info.message); // Si no hay usuario, mostrar mensaje de error
      return res.redirect('/login'); // Redirigir a login
    }
    
    req.logIn(user, (err) => {
      if (err) { return next(err); }

      // Aquí es donde agregarás los console.log
      console.log('Usuario autenticado:', user); // Verificar el usuario autenticado

      // Redirigir según el tipo de usuario
      if (user.tipo === 'Administrador') {
        console.log('Redirigiendo a la vista de administrador'); // Mensaje de depuración
        return res.redirect('/admin'); // Redirigir a la vista de admin
      } else {
        console.log('Redirigiendo a la vista de usuario'); // Mensaje de depuración
        return res.redirect('/'); // Redirigir a la vista de usuario
      }
    });
  })(req, res, next);
});

passport.use(new LocalStrategy((username, password, done) => {
  console.log('Intentando autenticar con:', username); // Log de usuario
  db.get("SELECT * FROM usuarios WHERE email = ?", [username], (err, user) => {
    if (err) {
      console.log('Error en la consulta:', err); // Log de error
      return done(err);
    }
    if (!user) {
      console.log('Usuario no encontrado'); // Log si no se encuentra el usuario
      return done(null, false, { message: 'Credenciales incorrectas' });
    }
    if (password !== user.password) {
      console.log('Contraseña incorrecta'); // Log si la contraseña es incorrecta
      return done(null, false, { message: 'Credenciales incorrectas' });
    }
    console.log('Usuario autenticado:', user); // Log del usuario autenticado
    return done(null, user);
  });
}));

app.get('/', (req, res) => {
  if (!req.isAuthenticated()) {
    return res.redirect('/login');
  }
  db.all("SELECT * FROM vehiculos WHERE estado = 'en parqueadero'", [], (err, rows) => {
    if (err) {
      throw err;
    }
    const totalEspacios = 100; // Cambia esto según la capacidad de tu parqueadero
    const espaciosOcupados = rows.length;
    const espaciosDisponibles = totalEspacios - espaciosOcupados;
    res.render('index', { vehiculos: rows, espaciosDisponibles });
  });
});

// Rutas para administradores
app.get('/admin', isAdmin, (req, res) => {
  db.all("SELECT * FROM vehiculos WHERE estado = 'en parqueadero'", [], (err, rows) => {
    if (err) {
      throw err;
    }
    res.render('admin', { vehiculos: rows });
  });
});

app.get('/agregar', isAdmin, (req, res) => {
  res.render('agregar');
});

// Rutas para administradores
app.get('/admin-panel', isAdmin, (req, res) => {
  db.all("SELECT * FROM vehiculos WHERE estado = 'en parqueadero'", [], (err, rows) => {
    if (err) {
      throw err;
    }
    res.render('admin', { vehiculos: rows });
  });
});

// Puedes cambiar la ruta de acceso a la vista de administración
app.get('/admin', (req, res) => {
  res.redirect('/admin-panel'); // Redirigir a la nueva ruta
});

// Otras rutas para administradores
app.get('/agregar', isAdmin, (req, res) => {
  res.render('agregar');
});

app.post('/agregar', isAdmin, (req, res) => {
  const { placa, modelo } = req.body;
  const fecha_ingreso = moment().tz("America/Bogota").format('YYYY-MM-DD HH:mm:ss');
  db.run("INSERT INTO vehiculos (placa, modelo, fecha_ingreso, estado) VALUES (?, ?, ?, 'en parqueadero')", [placa, modelo, fecha_ingreso], (err) => {
    if (err) {
      return console.log(err.message);
    }
    res.redirect('/admin-panel'); // Redirigir a la nueva ruta
  });
});


app.post('/agregar', isAdmin, (req, res) => {
  const { placa, modelo } = req.body;
  const fecha_ingreso = moment().tz("America/Bogota").format('YYYY-MM-DD HH:mm:ss');
  db.run("INSERT INTO vehiculos (placa, modelo, fecha_ingreso, estado) VALUES (?, ?, ?, 'en parqueadero')", [placa, modelo, fecha_ingreso], (err) => {
    if (err) {
      return console.log(err.message);
    }
    res.redirect('/admin');
  });
});

app.post('/salida', isAdmin, (req, res) => {
  const { id } = req.body; // ID del vehículo
  console.log('ID del vehículo recibido:', id); // Verificar ID

  const fecha_salida = moment().tz("America/Bogota").format('YYYY-MM-DD HH:mm:ss');

  db.get("SELECT * FROM vehiculos WHERE id = ?", [id], (err, vehiculo) => {
      if (err) {
          console.log('Error al obtener vehículo:', err.message);
          req.flash('error', 'Error al obtener vehículo');
          return res.redirect('/admin');
      }
      
      if (!vehiculo) {
          console.log('Vehículo no encontrado'); // Mensaje si no se encuentra el vehículo
          req.flash('error', 'Vehículo no encontrado');
          return res.redirect('/admin');
      }

      console.log('Vehículo encontrado:', vehiculo); // Verificar el vehículo encontrado

      db.run("UPDATE vehiculos SET fecha_salida = ?, estado = 'salido' WHERE id = ?", [fecha_salida, id], (err) => {
          if (err) {
              console.log('Error al actualizar estado del vehículo:', err.message);
              req.flash('error', 'Error al actualizar estado del vehículo');
              return res.redirect('/admin');
          }

          console.log('Estado del vehículo actualizado.'); // Confirmación de actualización
          req.flash('success', 'Salida registrada correctamente'); // Notificar éxito al usuario
          res.redirect('/admin'); // Redirigir a la página de administración después de registrar la salida
      });
  });
});

app.get('/reportes', isAdmin, (req, res) => {
  console.log('Accediendo a la ruta de reportes'); // Mensaje de depuración
  db.all("SELECT * FROM vehiculos", [], (err, rows) => {
    if (err) {
      console.log('Error al obtener reportes:', err.message); // Log de error
      return res.status(500).send('Error al obtener reportes'); // Enviar un error
    }
    console.log('Vehículos obtenidos:', rows); // Mensaje de depuración
    res.render('reportes', { vehiculos: rows });
  });
});

app.get('/reservas', isAdmin, (req, res) => {
  db.all("SELECT * FROM reservas", [], (err, rows) => {
    if (err) {
      console.log('Error al obtener reservas:', err.message); // Log de error
      return res.status(500).send('Error al obtener reservas'); // Enviar un error
    }
    res.render('reservas', { reservas: rows });
  });
});
app.post('/salida', isAdmin, (req, res) => {
  const { id } = req.body; // ID del vehículo
  console.log('ID del vehículo recibido:', id); // Verificar ID

  const fecha_salida = moment().tz("America/Bogota").format('YYYY-MM-DD HH:mm:ss');

  db.get("SELECT * FROM vehiculos WHERE id = ?", [id], (err, vehiculo) => {
      if (err) {
          console.log('Error al obtener vehículo:', err.message);
          req.flash('error', 'Error al obtener vehículo');
          return res.redirect('/admin');
      }
      
      if (!vehiculo) {
          console.log('Vehículo no encontrado'); // Mensaje si no se encuentra el vehículo
          req.flash('error', 'Vehículo no encontrado');
          return res.redirect('/admin');
      }

      console.log('Vehículo encontrado:', vehiculo); // Verificar el vehículo encontrado

      db.run("UPDATE vehiculos SET fecha_salida = ?, estado = 'salido' WHERE id = ?", [fecha_salida, id], (err) => {
          if (err) {
              console.log('Error al actualizar estado del vehículo:', err.message);
              req.flash('error', 'Error al actualizar estado del vehículo');
              return res.redirect('/admin');
          }

          console.log('Estado del vehículo actualizado. Generando factura...'); // Confirmación de actualización

          // Generar factura
          const total = calcularTotal(vehiculo.fecha_ingreso, fecha_salida);
          const fechaEmision = moment().tz("America/Bogota").format('YYYY-MM-DD HH:mm:ss');

          // Crear PDF
          const doc = new PDFDocument();
          const filePath = `./facturas/factura_${id}.pdf`;
          doc.pipe(fs.createWriteStream(filePath));
          
          doc.fontSize(25).text('Factura', { align: 'center' });
          doc.text(`Placa: ${vehiculo.placa}`);
          doc.text(`Total: $${total}`);
          doc.text(`Fecha de Emisión: ${fechaEmision}`);
          doc.end();

          console.log('Factura generada y guardada en:', filePath); // Confirmación de generación de factura

          req.flash('success', 'Factura generada correctamente'); // Notificar éxito al usuario
          res.redirect('/admin'); // Redirigir a la página de administración después de generar la factura
      });
  });
});

app.post('/aceptar-reserva', isAdmin, (req, res) => {
  const { id } = req.body; // ID de la reserva
  const fecha_ingreso = moment().tz("America/Bogota").format('YYYY-MM-DD HH:mm:ss');

  // Obtener la reserva para obtener la placa
  db.get("SELECT * FROM reservas WHERE id = ?", [id], (err, reserva) => {
    if (err) {
      console.log('Error al obtener reserva:', err.message);
      req.flash('error', 'Error al obtener reserva');
      return res.redirect('/reservas');
    }

    if (!reserva) {
      console.log('Reserva no encontrada');
      req.flash('error', 'Reserva no encontrada');
      return res.redirect('/reservas');
    }

    // Insertar el vehículo en la tabla de vehículos
    db.run("INSERT INTO vehiculos (placa, modelo, fecha_ingreso, estado) VALUES (?, ?, ?, 'en parqueadero')", 
      [reserva.placa, 'Modelo del Vehículo', fecha_ingreso], (err) => {
      if (err) {
        console.log('Error al agregar vehículo:', err.message);
        req.flash('error', 'Error al agregar vehículo');
        return res.redirect('/reservas');
      }

      // Actualizar el estado de la reserva a "aceptada"
      db.run("UPDATE reservas SET estado = 'aceptada' WHERE id = ?", [id], (err) => {
        if (err) {
          console.log('Error al actualizar estado de reserva:', err.message);
          req.flash('error', 'Error al actualizar estado de reserva');
          return res.redirect('/reservas');
        }

        req.flash('success', 'Reserva aceptada y vehículo agregado al parqueadero');
        res.redirect('/reservas'); // Redirigir a la lista de reservas
      });
    });
  });
});

app.post('/cancelar-reserva', (req, res) => {
  const { id } = req.body; // Obtener el ID de la reserva desde el cuerpo de la solicitud
  console.log('ID de la reserva a cancelar:', id); // Verificar el ID recibido

  // Verificar si el ID es válido
  if (!id) {
    console.log('ID de reserva no proporcionado');
    req.flash('error', 'ID de reserva no válido');
    return res.redirect('/reservas'); // Redirigir a la lista de reservas
  }

  // Verificar si la reserva existe en la base de datos
  db.get("SELECT * FROM reservas WHERE id = ?", [id], (err, reserva) => {
    if (err) {
      console.log('Error al verificar reserva:', err.message);
      req.flash('error', 'Error al verificar reserva');
      return res.redirect('/reservas'); // Redirigir a la lista de reservas
    }

    if (!reserva) {
      console.log('Reserva no encontrada');
      req.flash('error', 'Reserva no encontrada');
      return res.redirect('/reservas'); // Redirigir a la lista de reservas
    }

    // Si la reserva existe, proceder a actualizar su estado a "rechazada"
    db.run("UPDATE reservas SET estado = 'rechazada' WHERE id = ?", [id], (err) => {
      if (err) {
        console.log('Error al cancelar reserva:', err.message);
        req.flash('error', 'Error al cancelar reserva: ' + err.message); // Notificar error al usuario
        return res.redirect('/reservas'); // Redirigir a la lista de reservas
      }
      
      req.flash('success', 'Reserva rechazada correctamente');
      res.redirect('/reservas'); // Redirigir a la lista de reservas
    });
  });
});

function calcularTotal(fechaIngreso, fechaSalida) {
  const duracion = moment(fechaSalida).diff(moment(fechaIngreso), 'hours'); // Calcula la duración en horas
  const tarifaPorHora = 5000; // Establece tu tarifa por hora
  return duracion * tarifaPorHora; // Retorna el total
}

function isAdmin(req, res, next) {
  if (req.isAuthenticated() && req.user.tipo === 'admin') {
    return next();
  }
  res.redirect('/login'); // Redirigir a login si no es admin
}
// Ruta para mostrar reservas
app.get('/reservar', (req, res) => {
  if (!req.isAuthenticated()) {
    return res.redirect('/login');
  }
  res.render('reservar');
});

app.post('/reservar', (req, res) => {
  const { placa } = req.body;
  const fecha_reserva = moment().tz("America/Bogota").format('YYYY-MM-DD HH:mm:ss');
  db.run("INSERT INTO reservas (id_usuario, placa, fecha_reserva) VALUES (?, ?, ?)", [req.user.id, placa, fecha_reserva], (err) => {
    if (err) {
      return console.log(err.message);
    }
    res.redirect('/mis-reservas');
  });
});

// Ruta para mostrar mis reservas
app.get('/mis-reservas', (req, res) => {
  if (!req.isAuthenticated()) {
    return res.redirect('/login');
  }
  db.all("SELECT * FROM reservas WHERE id_usuario = ?", [req.user.id], (err, rows) => {
    if (err) {
      throw err;
    }
    res.render('mis-reservas', { reservas: rows });
  });
});


// Ruta para cerrar sesión
app.get('/logout', (req, res) => {
  req.logout((err) => {
    if (err) { return next(err); }
    res.redirect('/login'); // Redirigir a la página de login después de cerrar sesión
  });
});

// Middleware para verificar si el usuario es administrador
function isAdmin(req, res, next) {
  if (req.isAuthenticated() && req.user.tipo === 'admin') {
    return next();
  }
  res.redirect('/login'); // Redirigir a login si no es admin
}

// Iniciar el servidor
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});